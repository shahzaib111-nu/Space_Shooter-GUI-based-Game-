#include <iostream>
using namespace std;

// Recursive function to check pairs
bool findPair(int set[], int n, int sum, int& first, int& second, int start = 0) {
    if (start >= n - 1)
    { 
        return false;
    } 

    // Check the current pair (start, rest of the array)
    for (int i = start + 1; i < n; ++i) {
        if (set[start] + set[i] == sum) {
            first = set[start];
            second = set[i];
            return true; // Pair found
        }
    }

    return findPair(set, n, sum, first, second, start + 1);
}

int main() {
    int set[] = {3, 34, 4, 12, 2, 5};
    int n = sizeof(set) / sizeof(set[0]);
    int target;

    cout << "Enter a number: ";
    cin >> target;

    int first = 0, second = 0; 

    if (findPair(set, n, target, first, second)) {
        cout << "The pair [" << first << ", " << second << "] sums to " << target << endl;
    } else {
        cout << "No pair sums to " << target << endl;
    }

    return 0;
}
