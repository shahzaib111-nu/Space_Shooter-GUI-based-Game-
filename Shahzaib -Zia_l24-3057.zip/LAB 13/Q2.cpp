#include <iostream>
#include <string>
using namespace std;

void generatePermutations(string str, int start, int end) {
 // Base case: print the permutation
    if (start == end) {
        cout << str << endl; 
        return;
    }

    // Swap each character and recurse
    for (int i = start; i <= end; i++) {
        swap(str[start], str[i]); 
        generatePermutations(str, start + 1, end); // Recurse for the next position
        swap(str[start], str[i]); // Backtrack to restore the original string
    }
}

int main() {
    string input;
    cout << "Enter a string: ";
    cin >> input;
    int len=input.length();

    cout << "The permutations of the given string are:" << endl;
    generatePermutations(input, 0, len- 1);

    return 0;
}
