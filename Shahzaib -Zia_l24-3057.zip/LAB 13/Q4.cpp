#include <iostream>
#include <fstream>
#include <string>
using namespace std;

// Function to read the contents of the source file
string readFile(const string& sourceFile) {
    ifstream inputFile(sourceFile); // Open source file
    if (!inputFile) {
        cerr << "Error: Cannot open the source file: " << sourceFile << endl;
        return ""; 
    }
    string content, line;
    while (getline(inputFile, line)) {
        content += line + "\n"; // Append each line to the content string
    }

    inputFile.close(); // Close the source file
    return content;
}

// Function to write data to the destination file
void writeFile(const string& destFile, const string& content) {
    ofstream outputFile(destFile); // Open destination file
    if (!outputFile) {
        cerr << "Error: Cannot open the destination file: " << destFile << endl;
        return;
    }

    outputFile << content; // Write content to the destination file
    outputFile.close(); // Close the destination file
}

int main() {
    string sourceFile, destFile;
      sourceFile="source.txt";
      destFile="dest.txt";

    string content = readFile(sourceFile);
    if (content.empty()) {
        cerr << "No content to write. Exiting program." << endl;
        return 1;
    }
    writeFile(destFile, content);
    cout << "File copied successfully from \"" << sourceFile << "\" to \"" << destFile << "\"." << endl;
    return 0;
}
