#include<iostream>
#include<fstream>
#include<sstream>
#include<cstring>
using namespace std;
int countcharacter(const string& filename) {
	ifstream file(filename);
	if (!file) {
		cout << "error" << endl;
		return -1;
	}
	char vh;
	int counter = 0;
	while (file.get(vh)) {
		if (vh != '\n') {
			counter++;
		}
	}
	file.close();
	return counter;
}
int linecounter(const string& fileName) {
    ifstream inputFile(fileName);
    if (!inputFile) {
        cerr << "Error: Cannot open the file: " << fileName << endl;
        return -1;
    }

    string line;
    int lineCount = 0;

    while (getline(inputFile, line)) { // Read each line from the file
        lineCount++;
    }

    inputFile.close();
    return lineCount;
}
int wordcounter(const string& fileName) {
    ifstream inputFile(fileName);
    if (!inputFile) {
        cerr << "Error: Cannot open the file: " << fileName << endl;
        return -1;
    }

    string word;
    int wordCount = 0;

    while (inputFile >> word) { // This reads words separated by spaces or newlines
        wordCount++;
    }

    inputFile.close();
    return wordCount;
}
int main() {

	string inputfile = "content.txt";
	ifstream infile("sht.txt");
	int charcount = countcharacter(inputfile);
    cout << "Characters: " << charcount << endl;
	int wordcount = wordcounter(inputfile);
	 cout << "Words: " << wordcount << endl;
	int linecount = linecounter(inputfile);
    cout << "Lines: " << linecount << endl;



}